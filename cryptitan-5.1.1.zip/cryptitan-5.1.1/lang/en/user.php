<?php

return [
    'profile_not_found' => 'Profile could not be found.',
    'not_found' => 'User could not be found.',
];
