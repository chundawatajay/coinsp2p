<?php

return [
    'buyer_exists' => 'Giftcard already has a buyer.',
    'insufficient_stock' => 'Insufficient stock',
    'self_trading' => 'You cannot buy giftcard from yourself.',
    'sell_description' => 'Sold :count giftcard items',
    'buy_description' => 'Bought :count giftcard items',
];
